﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleBlockchain
{
    public partial class Form1 : Form
    {
        Blockchain blockchain;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            blockchain = new Blockchain();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            blockchain.AddBlock(new Block(blockchain.Chain.Count, DateTime.Now, textBox1.Text));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(blockchain.IsChainValid().ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (var block in blockchain.Chain)
            {
                MessageBox.Show($"Index: {block.Index}, Timestamp: {block.Timestamp}, Data: {block.Data}, Hash: {block.Hash}, PreviousHash: {block.PreviousHash}");
            }
        }
    }
}
