﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SimpleBlockchain
{
    public class Block
    {
        public int Index {  get; private set; }
        public DateTime Timestamp {  get; private set; }
        public string Data {  get; private set; }
        public string PreviousHash {  get; set; }
        public string Hash {  get;private set; }
        public int Nonce {  get;private set; }
        public Block(int index,DateTime timestamp,string data,string previoushash="")
        {
            Index = index;
            Timestamp = timestamp;
            Data = data;
            PreviousHash = previoushash;
            Hash = CalculateHash();
        }

        public string CalculateHash()
        {
            using(SHA256 sHA256 = SHA256.Create())
            {
                string rawData=Index.ToString()+Timestamp.ToString()+Data+PreviousHash+Nonce;
                byte[] bytes=sHA256.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder=new StringBuilder();
                foreach(byte b in bytes )
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
            
        }
        public void MineBlock(int Difficulty)
        {
            string targeted = new string('0', Difficulty);
            while(Hash.Substring(0,Difficulty)!=targeted)
            {
                Nonce++;
                Hash=CalculateHash();
            }
        }
    }
}
