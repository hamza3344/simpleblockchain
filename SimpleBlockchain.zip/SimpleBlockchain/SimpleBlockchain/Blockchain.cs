﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleBlockchain
{
    public class Blockchain
    {
        public IList<Block> Chain { get; private set; }
        public int difficulty { get; private set; } = 2;
        public Blockchain() { 
        Chain=new List<Block>();
            AddfirstBlock();
        }

        private void AddfirstBlock()
        {
            Chain.Add(CreateFirstBlock());
        }

        private Block CreateFirstBlock()
        {
            return new Block(0,DateTime.Now,"First Block","0");
        }
        public Block GetLatestBlock()
        {
            return Chain[Chain.Count-1];
        }
        public void AddBlock(Block newblock)
        {
            newblock.PreviousHash=GetLatestBlock().Hash;
            newblock.MineBlock(difficulty);
            Chain.Add(newblock);
        }
        public bool IsChainValid()
        {
            for(int i = 1;i<Chain.Count;i++)
            {
                Block currentBlock = Chain[i];
                Block previousBlock = Chain[i-1];
                if(currentBlock.Hash !=currentBlock.CalculateHash())
                {
                    return false;
                }
                if(currentBlock.PreviousHash !=previousBlock.Hash)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
